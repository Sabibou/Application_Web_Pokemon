# TP Web-Serveur

Vous pouvez démarrer avec la commande `./gradlew run`.

+ d'infos sur https://unicorn.artheriom.fr/
